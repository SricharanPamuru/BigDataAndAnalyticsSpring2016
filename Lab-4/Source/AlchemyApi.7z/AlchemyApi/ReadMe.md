# Eduonix NLP Application

## Tutorial code for basic AlchemyAPI Android Client
